#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include "./miracl/miracl.h"
#include "sm2.h"
#include "sm3.h"

long int get_seed()
{
    long int seed;
    struct timeval time_temp;
    gettimeofday(&time_temp, NULL );
    seed = 1000000 * time_temp.tv_usec + time_temp.tv_sec;
    return seed;
}

void sm2_init()
{
	big gx, gy, p, a, b;
	mip = mirsys(256, 2);
	mip->IOBASE = 16;
	sm2_ecc_parameter_n = mirvar(0);
	gx = mirvar(0);
	gy = mirvar(0);
	p = mirvar(0);
	a = mirvar(0);
	b = mirvar(0);
	/*
	cinstr(	p, "8542D69E4C044F18E8B92435BF6FF7DE457283915C45517D722EDB8B08F1DFC3");
	cinstr(	a, "787968B4FA32C3FD2417842E73BBFEFF2F3C848B6831D7E0EC65228B3937E498");
	cinstr(	b, "63E4C6D3B23B0C849CF84241484BFE48F61D59A5B16BA06E6E12D1DA27C5249A");
	cinstr(	gx, "421DEBD61B62EAB6746434EBC3CC315E32220B3BADD50BDC4C4E6C147FEDD43D");
	cinstr(	gy, "0680512BCBB42C07D47349D2153B70C4E5D7FDFCBFA36EA1A85841B9E46E09A2");
	cinstr(	n, "8542D69E4C044F18E8B92435BF6FF7DD297720630485628D5AE74EE7C32E79B7");
	*/

	cinstr(	p, "FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFF");
	cinstr(	a, "FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFC");
	cinstr(	b, "28E9FA9E9D9F5E344D5A9E4BCF6509A7F39789F515AB8F92DDBCBD414D940E93");
	cinstr(	gx, "32C4AE2C1F1981195F9904466A39C9948FE30BBFF2660BE1715A4589334C74C7");
	cinstr(	gy, "BC3736A2F4F6779C59BDCEE36B692153D0A9877CC62A474002DF32E52139F0A0");
	cinstr(	sm2_ecc_parameter_n, "FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFF7203DF6B21C6052B53BBF40939D54123");

	ecurve_init(a, b, p, MR_PROJECTIVE);
	sm2_ecc_basepoint_g = epoint_init();
	epoint_set( gx, gy, 1, sm2_ecc_basepoint_g);
}

void sm2_key_gen(SM2_KEY *key)
{
	big privkey,pubkey_x,pubkey_y,n_minus_1;
	epoint *pubkey;
	privkey = mirvar(0);
	pubkey_x = mirvar(0);
	pubkey_y = mirvar(0);
	n_minus_1 = mirvar(0);
	decr(sm2_ecc_parameter_n,1,n_minus_1);
	irand(get_seed());
	while(!mr_compare(privkey,mirvar(0)))
	{
		bigrand(n_minus_1,privkey);
	}
	ecurve_mult(privkey,sm2_ecc_basepoint_g,pubkey);
	epoint_get(pubkey,pubkey_x,pubkey_y);
	big_to_bytes(32,privkey,key->privkey,1);
	big_to_bytes(32,pubkey_x,key->pubkey_x,1);
	big_to_bytes(32,pubkey_y,key->pubkey_y,1);
	mirkill(privkey);
	mirkill(pubkey_x);
	mirkill(pubkey_y);
	mirkill(n_minus_1);
	epoint_free(pubkey);
}

int sm2_sign(big priv_key, big hash, big randnum, big* bin_r, big* bin_s)
{
	epoint *point;
	big x, y, e, r, s, pkey, pkey_1, tmp, tmp2, gx, gy;
	big rand;
	big zero, one;
	int res = 0;

	point = epoint_init();
	rand = mirvar(0);
	x = mirvar(0);
	y = mirvar(0);
	r = mirvar(0);
	s = mirvar(0);
	e = mirvar(0);
	zero = mirvar(0);
	one = mirvar(1);
	pkey = mirvar(0);
	pkey_1 = mirvar(0);
	tmp = mirvar(0);
	tmp2 = mirvar(0);
	
	copy(priv_key,pkey);
	copy(hash,e);
	copy(randnum,rand);

	do
	{
		ecurve_mult(rand, sm2_ecc_basepoint_g, point);
		epoint_get(point, x, y);
		mad(x, one, e, sm2_ecc_parameter_n, sm2_ecc_parameter_n, r);
		add(r, rand, tmp2);
		if( (!mr_compare(r, zero)) || (!mr_compare(tmp2, sm2_ecc_parameter_n)) )
		{
			res = -1;
			break;
		}
		incr(pkey, 1, pkey_1);	
		xgcd(pkey_1, sm2_ecc_parameter_n, pkey_1, pkey_1, pkey_1);
		mad(r, pkey, zero, sm2_ecc_parameter_n, sm2_ecc_parameter_n, tmp);
		subtract(rand, tmp, tmp2);
		mad(tmp2, one, sm2_ecc_parameter_n, sm2_ecc_parameter_n, sm2_ecc_parameter_n, tmp2);
		mad(pkey_1, tmp2, zero, sm2_ecc_parameter_n, sm2_ecc_parameter_n, s);
		if(!mr_compare(s, zero))
		{
			res = -1;
			break;
		}

	}while(0);

	copy(r,*bin_r);
	copy(s,*bin_s);

	mirkill(rand);
	mirkill(x);
	mirkill(y);
	mirkill(r);
	mirkill(s);
	mirkill(e);
	mirkill(zero);
	mirkill(one);
	mirkill(pkey);
	mirkill(pkey_1);
	mirkill(tmp);
	mirkill(tmp2);
	epoint_free(point);
	return res;
}


int sm2_check(big bin_r, big bin_s, big hash, big pub_x, big pub_y)
{
	big e, r, s, t, x, y, zero, one, tmp;
	epoint *point;
	int res = 0;

	point = epoint_init();
	x = mirvar(0);
	y = mirvar(0);
	r = mirvar(0);
	s = mirvar(0);
	t = mirvar(0);
	e = mirvar(0);
	tmp = mirvar(0);
	zero = mirvar(0);
	one = mirvar(1);

	copy(hash,e);
	copy(bin_r,r);
	copy(bin_s,s);
	copy(pub_x,x);
	copy(pub_y,y);

	do
	{
		mad(r, one, s, sm2_ecc_parameter_n, sm2_ecc_parameter_n, t);
		if(!mr_compare(t, zero))
		{
			res = -1;
			break;
		}
		if(!epoint_set(x, y, 0, point))
		{
			res = -1;
			break;
		}
		ecurve_mult2(s, sm2_ecc_basepoint_g, t, point, point);
		epoint_get(point, x, y);
		mad(e, one, x, sm2_ecc_parameter_n, sm2_ecc_parameter_n, tmp);
		if(mr_compare(tmp, r))
		{
			res = -1;
			break;
		}
	}while(0);

	mirkill(x);
	mirkill(y);
	mirkill(r);
	mirkill(s);
	mirkill(t);
	mirkill(e);
	mirkill(zero);
	mirkill(one);
	mirkill(tmp);
	epoint_free(point);
	return res;
}

/*
int main()
{
	int sign_result,check_result;
	big gx, gy, p, a, b, priv_key, hash, randnum, bin_r, bin_s, pubx, puby;
	epoint *pubkey;
	mip = mirsys(256, 2);
	mip->IOBASE = 16;
	sm2_ecc_parameter_n = mirvar(0);
	gx = mirvar(0);
	gy = mirvar(0);
	p = mirvar(0);
	a = mirvar(0);
	b = mirvar(0);
	priv_key = mirvar(0);
	hash = mirvar(0);
	randnum = mirvar(0);
	bin_r = mirvar(0);
	bin_s = mirvar(0);
	pubx = mirvar(0);
	puby = mirvar(0);
	cinstr(	p, "8542D69E4C044F18E8B92435BF6FF7DE457283915C45517D722EDB8B08F1DFC3");
	cinstr(	a, "787968B4FA32C3FD2417842E73BBFEFF2F3C848B6831D7E0EC65228B3937E498");
	cinstr(	b, "63E4C6D3B23B0C849CF84241484BFE48F61D59A5B16BA06E6E12D1DA27C5249A");
	cinstr(	gx, "421DEBD61B62EAB6746434EBC3CC315E32220B3BADD50BDC4C4E6C147FEDD43D");
	cinstr(	gy, "0680512BCBB42C07D47349D2153B70C4E5D7FDFCBFA36EA1A85841B9E46E09A2");
	cinstr(	sm2_ecc_parameter_n, "8542D69E4C044F18E8B92435BF6FF7DD297720630485628D5AE74EE7C32E79B7");

	cinstr(	p, "FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFF");
	cinstr(	a, "FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFC");
	cinstr(	b, "28E9FA9E9D9F5E344D5A9E4BCF6509A7F39789F515AB8F92DDBCBD414D940E93");
	cinstr(	gx, "32C4AE2C1F1981195F9904466A39C9948FE30BBFF2660BE1715A4589334C74C7");
	cinstr(	gy, "BC3736A2F4F6779C59BDCEE36B692153D0A9877CC62A474002DF32E52139F0A0");
	cinstr(	sm2_ecc_parameter_n, "FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFF7203DF6B21C6052B53BBF40939D54123");

	cinstr(priv_key,"128B2FA8BD433C6C068C8D803DFF79792A519A55171B1B650C23661D15897263");
	cinstr(hash,"B524F552CD82B8B028476E005C377FB19A87E6FC682D48BB5D42E3D9B9EFFE76");
	cinstr(randnum,"6CB28D99385C175C94F94E934817663FC176D925DD72B727260DBAAE1FB2F96F");
	
	ecurve_init(a, b, p, MR_PROJECTIVE);
	sm2_ecc_basepoint_g = epoint_init();
	epoint_set( gx, gy, 1, sm2_ecc_basepoint_g);

	pubkey = epoint_init();

	sign_result = sm2_sign(priv_key,hash,randnum,&bin_r,&bin_s);
	ecurve_mult(priv_key,sm2_ecc_basepoint_g,pubkey);
	epoint_get(pubkey,pubx,puby);
	check_result = sm2_check(bin_r,bin_s,hash,pubx,puby);
	printf("结果：%d %d\n", sign_result,check_result);
}*/