#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "./miracl/miracl.h"
#include "sm2.h"
#include "sm3.h"


int main()
{
	int sign_result,check_result;
	big priv_key, hash, randnum, bin_r, bin_s, pubx, puby;
	epoint *pubkey;

    sm2_init();

	priv_key = mirvar(0);
	hash = mirvar(0);
	randnum = mirvar(0);
	bin_r = mirvar(0);
	bin_s = mirvar(0);
	pubx = mirvar(0);
	puby = mirvar(0);

	cinstr(priv_key,"128B2FA8BD433C6C068C8D803DFF79792A519A55171B1B650C23661D15897263");
	cinstr(hash,"B524F552CD82B8B028476E005C377FB19A87E6FC682D48BB5D42E3D9B9EFFE76");
	cinstr(randnum,"6CB28D99385C175C94F94E934817663FC176D925DD72B727260DBAAE1FB2F96F");

	//公钥生成
	pubkey = epoint_init();
    ecurve_mult(priv_key,sm2_ecc_basepoint_g,pubkey);
	epoint_get(pubkey,pubx,puby);

	sign_result = sm2_sign(priv_key,hash,randnum,&bin_r,&bin_s);
	check_result = sm2_check(bin_r,bin_s,hash,pubx,puby);
	printf("结果：%d %d\n", sign_result,check_result);
}

/*
int main()
{
    miracl *mip;
    mip = mirsys(256,2);
    mip->IOBASE = 16;
    big x;
    x = mirvar(0);
    unsigned char m[3] = "abc";
    unsigned char result[32];
    sm3_hash( m, 3, result );
    bytes_to_big(32,result,x);
    cotnum(x,stdout);
}*/

/*
int main()
{
	int sign_result,check_result;
	big priv_key, hash, randnum, bin_r, bin_s, pubx, puby;
	epoint *pubkey;
    SM2_KEY *sm2_key;

    sm2_init();

	priv_key = mirvar(0);
	hash = mirvar(0);
	randnum = mirvar(0);
	bin_r = mirvar(0);
	bin_s = mirvar(0);
	pubx = mirvar(0);
	puby = mirvar(0);

    sm2_key = malloc(sizeof(SM2_KEY*));
    sm2_key_gen(sm2_key);
	cinstr(hash,"B524F552CD82B8B028476E005C377FB19A87E6FC682D48BB5D42E3D9B9EFFE76");
	cinstr(randnum,"6CB28D99385C175C94F94E934817663FC176D925DD72B727260DBAAE1FB2F96F");
    printf("1");
    bytes_to_big(32,sm2_key->privkey,priv_key);
    cotnum(priv_key,stdout);
	//sign_result = sm2_sign(priv_key,hash,randnum,&bin_r,&bin_s);
	//check_result = sm2_check(bin_r,bin_s,hash,pubx,puby);
	//printf("结果：%d %d\n", sign_result,check_result);
}*/