typedef struct 
{
    unsigned char privkey[32];
    unsigned char pubkey_x[32];
    unsigned char pubkey_y[32];
} SM2_KEY;

epoint *sm2_ecc_basepoint_g;
miracl *mip;
big sm2_ecc_parameter_n;

long int get_seed();
int sm2_check(big bin_r, big bin_s, big hash, big pub_x, big pub_y);
int sm2_sign(big priv_key, big hash, big randnum, big* bin_r, big* bin_s);
void sm2_init();
void sm2_key_gen(SM2_KEY *key);